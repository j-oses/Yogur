package yogur.tree.declaration.declarator;

import yogur.tree.AbstractTreeNode;

public abstract class Declarator extends AbstractTreeNode {
}
