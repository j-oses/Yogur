package yogur.tree.declaration;

import yogur.tree.declaration.Declaration;

public interface FunctionOrVarDeclaration extends Declaration {
}
