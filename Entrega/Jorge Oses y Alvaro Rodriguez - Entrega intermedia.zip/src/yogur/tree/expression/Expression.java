package yogur.tree.expression;

import yogur.tree.AbstractTreeNode;

public abstract class Expression extends AbstractTreeNode {

}
