package yogur.tree.statement;

import yogur.tree.AbstractTreeNode;
import yogur.tree.StatementOrDeclaration;

public abstract class Statement extends AbstractTreeNode implements StatementOrDeclaration {

}
