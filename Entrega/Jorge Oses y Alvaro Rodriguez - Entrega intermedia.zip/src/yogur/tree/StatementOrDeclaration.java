package yogur.tree;

public interface StatementOrDeclaration extends AbstractTreeNodeInterface {

}
