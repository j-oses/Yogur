package yogur.tree.declaration;

import yogur.tree.StatementOrDeclaration;

public interface Declaration extends StatementOrDeclaration {
	String getDeclarationDescription();
}
